Pure CSS percentage circle
==========================

I found this really nice percentage circle and simply loved it.
Since I found nothing like this on github and I needed the source code in LESS, I just transformed the SASS code to LESS and put it into that repo for reuse or further development.

Thanks a lot to André Firchow, who developed this circle. For more information go to his blog: http://firchow.net/css3-prozentanzeige-kreis/.
A live demo can be found here: http://circle.firchow.net/
